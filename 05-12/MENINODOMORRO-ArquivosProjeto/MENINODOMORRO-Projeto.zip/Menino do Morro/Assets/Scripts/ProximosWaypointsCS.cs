﻿using UnityEngine;
using System.Collections;

public class ProximosWaypointsCS : MonoBehaviour {


	// Criar uma lista de Objetos do TIPO GameObject!
	// Uma lista e' marcada pelos []
	public GameObject[] listaProximos;
	
	public Transform ObterProximaPosicao () {     
		int indiceRandomicoDaListaObjetos = Random.Range(0,listaProximos.Length);			// lista aleatoria de waypoints
		GameObject objetoObtido = listaProximos[indiceRandomicoDaListaObjetos];			// inclui objeto na lista aleatoria
		Transform transformObjeto = objetoObtido.transform;								// objeto definido de forma aleatoria
		return transformObjeto;																	// retonar qual objeto sera o proximo waypoint
	}
	
	

}
