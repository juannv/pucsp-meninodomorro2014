﻿using UnityEngine;
using System.Collections;

public class EnemyCounter : MonoBehaviour {
	
	// DECLARACAO E INICIALIZACAO DE VARIAVEIS
	
	public GameObject[] enemies;
	int enemiesLeft;
	ArrayList inimigos;
	public GameObject[] listaMostrar;
	public bool cenarioFinal = false;
	
	
	void Start ()
	{
		inimigos = new ArrayList ();
		GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
		enemiesLeft = enemies.Length;
		foreach (GameObject obj in enemies) {
			inimigos.Add(obj.GetComponent<EnemyScript>());
		}
	}
	
	void Update () {
		// PARA CADA OBJETO QUE POSSUA UM ENEMYSCRIPT E ENQUANTO NAO ESTIVER MORTO, ADICIONE MAIS UM A LISTA DE INIMIGOS
		enemiesLeft = 0;
		if (inimigos != null) {
			foreach (EnemyScript s in inimigos)
				if (!s.mateInimigo)
					enemiesLeft++;
			
			// SE O NUMERO DE INIMIGOS FOR IGUAL A ZERO E NAO FOR O CENARIO FINAL, HABILITAR OS OBJETOS
			if (enemiesLeft == 0 && cenarioFinal == false) {
				foreach (GameObject obj in listaMostrar) {	// para cada objeto listado a ser escondido
					obj.SetActive (true);
					
				}
			}
		}
	}
}