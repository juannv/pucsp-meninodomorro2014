﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class audio : MonoBehaviour {
	// DECLARA E INICIALIZA VARIAVEIS
	public float volumeSlider = 10.0F;		// tamanho da barra de volume
	static float volume;					// variavel de volume
	public bool menuInicial;

	void OnGUI()
	{
		if (menuInicial) {		// SE FOR SLIDER DO MENU INICIAL
						volumeSlider = GUI.HorizontalSlider (new Rect (Screen.width / 2 + 210, Screen.height / 2 + 90, 100, 5), volumeSlider, 0.0F, 1.0F);	// posicao da barra, tamanho da barra e valores de inicio/fim
						AudioListener.volume = volumeSlider;						//volume igual a 0.1 vezes a posicao da barra
				}
		else 					// SE FOR SLIDER DO MENU INGAME
		{
			volumeSlider = GUI.HorizontalSlider (new Rect (Screen.width / 2 + 210, Screen.height / 2 - 45, 100, 5), volumeSlider, 0.0F, 1.0F);	// posicao da barra, tamanho da barra e valores de inicio/fim
			AudioListener.volume = volumeSlider;						//volume igual a 0.1 vezes a posicao da barra
				}
	}
}
