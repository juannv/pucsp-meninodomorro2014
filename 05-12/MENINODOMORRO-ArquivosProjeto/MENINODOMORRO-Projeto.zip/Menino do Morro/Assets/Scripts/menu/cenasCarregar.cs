﻿using UnityEngine;
using System.Collections;

public class cenasCarregar : MonoBehaviour {

	// DECLARACAO E INICIALIZACAO DE VARIAVEIS

	private string nomedacena = "1-1 Loading";	// nome da cena a ser carregada
	private string menu = "1 Menu";
	private string pont = "10 Pont";
	public string faseJogada = "3 Cidade";
	public bool novoMenu;
	public bool loadMenu;
	public bool sairMenu;
	public bool novoInGame;
	public bool sairInGame;
	public bool novoPont;
	public bool sairPont;
	
	
	void Awake ()
	{
		faseJogada = PlayerPrefs.GetString ("ChaveUltimaFase", "3 Cidade");
	}
	
	// AO CLICAR NO BOTAO SETADO COMO NOVOMENU, SEU SAVE SERA RESETADO E O JOGO SERIA INICIADO

	void OnMouseDown ()
	{
		// AO CLICAR NO BOTAO SETADO COMO NOVOMENU, SEU SAVE SERA RESETADO E O JOGO SERIA INICIADO DESDE O COMECO
		if (novoMenu){
			PlayerPrefs.DeleteKey ("ChaveSalvarPontos");
			PlayerPrefs.DeleteKey ("ChaveInimigosMortos");
			PlayerPrefs.DeleteKey("ChaveUltimaFase");
			Application.LoadLevel(nomedacena);
		}
		// AO CLICAR NO BOTAO SETADO COMO LOADMENU, SEU JOGO SERA INICIADO A PARTIR DO ULTIMO PONTO SALVO
		if (loadMenu) {
			Application.LoadLevel (faseJogada);
		}
		// AO CLICAR NO BOTAO SETADO COMO SAIRMENU, O JOGO SERA ENCERRADO
		if (sairMenu) {
			Application.Quit();
		}
		// AO CLICAR NO BOTAO SETADO COMO NOVOINGAME, SEU JOGO SERA INICIADO A PARTIR DO ULTIMO PONTO SALVO
		if (novoInGame) {
			Application.LoadLevel(faseJogada);
		}
		// AO CLICAR NO BOTAO SETADO COMO SAIRINGAME, SEU JOGO MOSTRARA A TELA DE PONTUACAO COM OS ULTIMOS DADOS SALVOS
		if (sairInGame) {			
			Application.LoadLevel (pont);
		}
		// AO CLICAR NO BOTAO SETADO COMO NOVOPONT, SEU JOGO SERA CARREGADO A PARTIR DO ULTIMO PONTO SALVO
		if (novoPont) {
			Application.LoadLevel (faseJogada);
		}
		// AO CLICAR NO BOTAO SETADO COMO SAIRPONT, O JOGO CARREGARA O MENU
		if (sairPont){
			Application.LoadLevel (menu);

		}
	}
}