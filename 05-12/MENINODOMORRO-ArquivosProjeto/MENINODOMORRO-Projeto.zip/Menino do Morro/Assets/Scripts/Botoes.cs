﻿using UnityEngine;
using System.Collections;

public class Botoes :  Administrador_Botoes
{


	// DECLARACAO E INICIALIZACAO DE VARIAVEIS

	public GameObject 
		Tela,
		BarraNegra;

	public bool Selecionado;

	public Administrador_Botoes _administradorBotoes;

	public void Start()
	{
		_administradorBotoes = GameObject.Find ("Administrador de Botões").GetComponent<Administrador_Botoes> ();

		BarraNegra.SetActive(false);
		Tela.SetActive (false);
		Debug.Log (this.gameObject.name);

		DesativarBotoesInternos ();
	}

	// AO COLOCAR O MOUSE SOBRE O BOTAO, UMA TARJA PRETA ACENDERA SOB O BOTAO

	void OnMouseOver()
	{
		BarraNegra.SetActive (true);
	}

	// AO RETIRAR O MOUSE DO BOTAO, A TARJA PRETA SE APAGARA SOB O BOTAO SE O BOTAO NAO ESTIVER CLICADO

	void OnMouseExit()
	{
		if(Selecionado)
			BarraNegra.SetActive (true);
		else if(!Selecionado)
			BarraNegra.SetActive(false);
	}


	// SE DETERMINADO BOTAO FOR CLICADO, OUTRA TELA IRA SURGIR, JUNTO COM SEUS NOVOS BOTOES, ENQUANTO DESABILITA OUTROS
	void OnMouseDown()
	{
		_administradorBotoes.Troca_Botoes ((string)this.gameObject.name);

		if ((string)this.gameObject.name == "Botao Creditos" || (string)this.gameObject.name == "BotãoCreditos TrocaTela Esq" || (string)this.gameObject.name == "BotãoCreditos TrocaTela Dir") 
		{
			BoxCollider2D[] BCInternos = GameObject.Find("Botão Créditos 2").GetComponentsInChildren<BoxCollider2D>();
			foreach(BoxCollider2D boxes in BCInternos)
				boxes.enabled = true;
		}
		else
		{
			BoxCollider2D[] BCInternos = GameObject.Find("Botão Créditos 2").GetComponentsInChildren<BoxCollider2D>();
			foreach(BoxCollider2D boxes in BCInternos)
				boxes.enabled = false;
		}

		if ((string)this.gameObject.name == "Botao Tutorial" || (string)this.gameObject.name == "BotãoTuto TrocaTela Esq" || (string)this.gameObject.name == "BotãoTuto TrocaTela Dir") 
		{
			BoxCollider2D[] BCInternos = GameObject.Find("Botao Tutorial 2").GetComponentsInChildren<BoxCollider2D>();
			foreach(BoxCollider2D boxes in BCInternos)
				boxes.enabled = true;
		}

		else
		{
			BoxCollider2D[] BCInternos = GameObject.Find("Botao Tutorial 2").GetComponentsInChildren<BoxCollider2D>();
			foreach(BoxCollider2D boxes in BCInternos)
				boxes.enabled = false;
		}
	}

	// AO HABILITAR BOTOES COM CLIQUES, OUTROS INACESSIVEIS NO MOMENTO FICAM BLOQUEADOS
	void DesativarBotoesInternos()
	{
		BoxCollider2D[] BCInternosCreditos = GameObject.Find("Botão Créditos 2").GetComponentsInChildren<BoxCollider2D>();
		foreach(BoxCollider2D boxes in BCInternosCreditos)
		{
			boxes.enabled = false;
		}
		
		BoxCollider2D[] BCInternosTuto = GameObject.Find("Botao Tutorial 2").GetComponentsInChildren<BoxCollider2D>();
		foreach(BoxCollider2D boxes in BCInternosTuto)
		{
			boxes.enabled = false;
		}
	}
}
