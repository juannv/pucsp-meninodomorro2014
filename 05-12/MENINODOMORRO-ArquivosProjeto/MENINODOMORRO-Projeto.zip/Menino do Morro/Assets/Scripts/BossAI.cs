﻿using UnityEngine;
using System.Collections;

public class BossAI : MonoBehaviour {

	// DECLARACAO DE VARIAVEIS
	public Animator animator;
	public AudioClip audioAtirando;			
	public AudioClip audioRecarregando;
	public GameObject jogador;
	public LayerMask layerMaskEnemy;
	public float tempoDisparo = 0.5f;
	public float tempoRecarregar = 1.5f;
	public int estadoBoss = 1; // 1= carregando e 2= atirando
	public float contadorTempo = 0.0f;
	public bool ignorarJogador = false;
	
	
	void Start () {
		jogador = GameObject.FindGameObjectWithTag("Player");			// variavel jogador sera composta pelo objeto com tag player
		animator = this.gameObject.GetComponentInChildren<Animator>();	// animator sera o animator filho deste objeto
		audio.clip = audioRecarregando;									// valor inicial do audio
		audio.Play();													// toca audio

	}
	
	
	
	void Update () {
		transform.LookAt(jogador.transform.position);					// olhar para jogador
		contadorTempo = Time.deltaTime + contadorTempo;					// contador de tempo
		RaycastHit2D hit  = Physics2D.Linecast(transform.position, jogador.transform.position, layerMaskEnemy);		// disparo em direcao ao jogador
		if(hit.collider != null && estadoBoss == 2) {					// colisor diferente de vazio e boss atirando
			if(hit.collider.gameObject.tag.Equals("Player")) {			// colidir com tag player
				jogador.SendMessage("jogadorMorre");					// jogador morre
			}
			
		}
		
		
		if(contadorTempo >= tempoRecarregar && estadoBoss == 1) {			// contador e estado do boss como condicoes
			contadorTempo = 0;												// reseta contador
			animator.Play("Matheus - Shoot");								// animacao atirando
			audio.Stop();													// para o audio anterior
			audio.clip = audioAtirando;										// muda faixa de audio
			audio.Play();													// toca audio atual
			audio.loop = true;												// toca audio em loop
			estadoBoss = 2;													// muda estado do boss para atirando
			
		}
		if(contadorTempo >= tempoDisparo && estadoBoss == 2) {				// contador e estado do boss como condicoes
			contadorTempo = 0;												// reseta contador
			audio.Stop();													// para o audio anterior
			audio.clip = audioRecarregando;									// muda faixa de audio
			audio.Play();													// toca audio atual
			animator.Play("Matheus - Carregando");
			
			estadoBoss = 1;													// muda estado do boss para carregando
		}
		
		if (ignorarJogador == true)											// se ignorar jogador
		{
			animator.Play("Matheus - Idle");								// animacao idle
			audio.Stop();													// para o audio
		}
		
	}
	
	
	
	public void IgnorarPlayer() {											// funcao usada pelo script morte do jogador
		ignorarJogador = true;												// ignora jogador
	}
	
}