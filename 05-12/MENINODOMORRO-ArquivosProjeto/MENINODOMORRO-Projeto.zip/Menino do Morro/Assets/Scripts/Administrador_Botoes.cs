﻿using UnityEngine;
using System.Collections;

public class Administrador_Botoes : MonoBehaviour 
{
	private GameObject[] ArrayBotoes;

	//public BoxCollider2D[] BotoesParaDesativar;

	// Use this for initialization

	// Update is called once per frame
	

	public void Troca_Botoes (string NomeDoBotaoSelecionado) 
	{
		ArrayBotoes = GameObject.FindGameObjectsWithTag("BotaoDoMenu");		// incrementa arraybotoes com objetos usando a tag BotaoDoMenu

		foreach(GameObject bot in ArrayBotoes)
		{
			Botoes botAtual = bot.GetComponent<Botoes>()as Botoes;	//altera botao atual
			botAtual.BarraNegra.SetActive(false);				// desativa objeto
			botAtual.Tela.SetActive(false);						// desativa objeto
			botAtual.Selecionado = false;						// desativa objeto
			botAtual.enabled = false;							// desativa objeto
		}

		Botoes botaoASerAtivado = GameObject.Find (NomeDoBotaoSelecionado).GetComponent<Botoes> () as Botoes;		// encontra objetos com script Botoes

		botaoASerAtivado.Selecionado = true;						// exibir objeto
		botaoASerAtivado.BarraNegra.SetActive (true);				// exibir objeto
		botaoASerAtivado.Tela.SetActive (true);						// exibir objeto
		botaoASerAtivado.enabled = true;							// exibir objeto
	}

	public void Troca_Tela()
	{
	}
}
