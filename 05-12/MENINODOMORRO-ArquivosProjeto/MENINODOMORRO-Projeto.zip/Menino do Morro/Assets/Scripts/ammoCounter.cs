﻿using UnityEngine;
using System.Collections;

public class ammoCounter : MonoBehaviour {
	public Weapon muni;
	
	// CONTADOR DE MUNICAO A SER EXIBIDO NA TELA
	void Awake ()
	{
		muni = GameObject.FindObjectOfType <Weapon> ();
	}
	
	void Update () {
		guiText.text = "" + muni.pistolAmmo;
	}
}