﻿using UnityEngine;
using System.Collections;

public class morte : MonoBehaviour {

	// DECLARA E INICIALIZA VARIAVEIS
	private Animator animator;
	
	public GameObject[] exibirGUI;
	public GameObject[] inimigo;
	private bool morto;
	public bool boss;
	void Awake ()
	{
		animator = gameObject.GetComponentInChildren<Animator> ();
	}


	// FUNÇAO CHAMADA ATRAVES DE OUTRO SCRIPT, QUANDO ATIVA DEVE FAZER COM QUE OS INIMIGOS ESQUECAM DO JOGADOR

	public void jogadorMorre()
	{	
		if (morto == false) {
			//Debug.Log("atingido");
			morto = true;
			//inimigo = GameObject as GameObject[];
			foreach (GameObject inim in inimigo) {
				if(inim == null) continue;
				if (boss == false)
				{inim.gameObject.GetComponent<AIWayPointsCS>().IgnorarPlayer();}
				if (boss == true)
				{inim.gameObject.GetComponent<BossAI>().IgnorarPlayer();}
			}
			
		}
		// QUANDO SETADO COMO TRUE, OS COMPONENTES DO JOGADOR DEVEM SER DESTRUIDOS E TOCARA A ANIMACAO DE MORTE DO JOGADOR, BEM COMO O AVISO NA TELA
		if (morto == true) {
			foreach (GameObject tela in exibirGUI) {
				tela.SetActive (true);
			}
			
			Component objAI = GetComponent ("movimentacao");
			Component objAI2 = GetComponentInChildren<rotate> ();
			Component objAI3 = GetComponent<CircleCollider2D> ();
			Component objAI4 = GetComponentInChildren<Weapon> ();
			Component objAI5 = GetComponentInChildren<ControleAnim> ();
			Destroy (objAI);
			Destroy (objAI2);
			Destroy (objAI3);
			Destroy (objAI4);
			Destroy (objAI5);
			animator.Play ("Marcos - Dying");
		}
		
	}
	
	// AO COLIDIR COM O INIMIGO, JOGADOR SE TORNA "MORTO", SEUS COMPONENTES SAO DESTRUIDOS E A ANIMACAO DE MORTE SERA EXECUTADA, BEM COMO O AVISO NA TELA
	void OnCollisionEnter2D(Collision2D outroColisor)
	{
		if(outroColisor.gameObject.tag == "Enemy")			// se o colisor2D deste objeto colidir com um colisor com a tag Player
		{
			if (morto == false) {
				foreach (GameObject inim in inimigo) {
					inim.gameObject.GetComponent ("AIWayPointsCS").SendMessage ("IgnorarPlayer");
				}
				morto = true;
			}
			if (morto == true) {
				foreach (GameObject tela in exibirGUI) {
					tela.SetActive (true);
				}
				
				Component objAI = GetComponent("movimentacao");
				Component objAI2 = GetComponentInChildren<rotate>();
				Component objAI3 = GetComponent<CircleCollider2D>();
				Component objAI4 = GetComponentInChildren<Weapon>();
				Component objAI5 = GetComponentInChildren<ControleAnim>();
				Destroy(objAI);
				Destroy(objAI2);
				Destroy(objAI3);
				Destroy(objAI4);
				Destroy(objAI5);
				animator.Play ("Marcos - Dying");				
			}
		}
	}
}