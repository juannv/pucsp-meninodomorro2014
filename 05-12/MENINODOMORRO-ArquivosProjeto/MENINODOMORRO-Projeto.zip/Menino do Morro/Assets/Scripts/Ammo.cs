﻿using UnityEngine;
using System.Collections;

public class Ammo : MonoBehaviour {
	
	public GameObject pistola;
	public bool onTrigger = false;
	Collider2D outroColisor2;


	void Update ()
	{
		if (Input.GetButtonDown ("Interact") && onTrigger)			// DENTRO DO TRIGGER PRESSIONE O BOTAO INTERACT
		{
			audio.Play();											// TOCA AUDIO
			outroColisor2.gameObject.GetComponentInChildren<Weapon>().getWeapon();	// OBTEM SCRIPT Weapon NavMeshObstacle FILHO do COLISOR	
			Component spriteAmmo = GetComponent<SpriteRenderer>();	// SPRITE DA ARMA
			Destroy(spriteAmmo);									// DESTRUIR SPRITE
			Component colliderAmmo = GetComponent<BoxCollider2D>();	// COLLIDER
			Destroy(colliderAmmo);									// DESTRUIR COLLIDER
			onTrigger = false;										// PLAYER PERDE EFEITO SOBRE OBJETO
		}
		
	}
	
	void OnTriggerEnter2D (Collider2D outroColisor)			// AO ENTRAR NO TRIGGER, PLAYER TERA ACAO
	{
		if (outroColisor.gameObject.tag == "Player")
		{
			onTrigger=true;
			outroColisor2 = outroColisor;
			
		}
		
	}
	
	void OnTriggerExit2D (Collider2D outroColisor)		// AO SAIR DO TRIGGER, NAO TERA MAIS EFEITO
	{
		if (outroColisor.gameObject.tag == "Player")		
		{
			onTrigger=false;
			
		}
		
	}
	
}
