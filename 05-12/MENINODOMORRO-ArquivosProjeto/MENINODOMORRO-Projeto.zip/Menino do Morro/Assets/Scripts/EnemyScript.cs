﻿using UnityEngine;
using System.Collections;

public class EnemyScript : MonoBehaviour {

	// DECLARACAO E INICIALIZACAO DE VARIAVEIS

	public Animator animator = new Animator();		// inicia um animator
	private string animFinal =   "9-1 AnimFinal";
	public bool mateInimigo = false;
	public bool e1;
	public bool e2;
	public bool boss;
	public int BossHealth = 5;
	public int pontosDerrota = 0;
	public SpriteRenderer SRInimigo;
	public string layerNameDead = "Morto";
	public GameObject ammo;
	public Weapon savedScore;


	void Start () {
		savedScore = GameObject.FindObjectOfType<Weapon> ();
	}

	// MATAR INIMIGO A SER CHAMADO DE OUTRO SCRIPT
	public void MatarInimigo()
	{
		mateInimigo = true;
		
	}
	public void Update() {
		
		// SE FOR INIMIGO2, TOCAR ANIMACAO DE MORTE, DESATIVAR ESTES COMPONENTES E MANDAR O SPRITE PARA A LAYER DEFINIDA
		if (e2)
		{
			if (mateInimigo) {
				animator.Play ("Inimigo2 - Dying");	// tocar a animacao Inimigo2 - Dead
				Component objAI = GetComponent("AIWayPointsCS");
				Component objAI2 = GetComponent<CircleCollider2D>();
				Destroy(objAI);
				Destroy(objAI2);
				Destroy(GetComponent<EnemyScript>());
				SRInimigo.sortingLayerName = layerNameDead;
				if (ammo != null){
					ammo.SetActive (true);}
			}
			
		}
		// SE FOR INIMIGO1, TOCAR ANIMACAO DE MORTE, DESATIVAR ESTES COMPONENTES E MANDAR O SPRITE PARA A LAYER DEFINIDA
		if (e1)
		{
			if (mateInimigo) {
				animator.Play ("Inimigo1 - Dying");	// tocar a animacao Inimigo1 - Dead
				Component objAI = GetComponent ("AIWayPointsCS");
				Component objAI2 = GetComponent<CircleCollider2D> ();
				Destroy (objAI);
				Destroy (objAI2);
				Destroy (GetComponent<EnemyScript> ());
				SRInimigo.sortingLayerName = layerNameDead;
				if (ammo != null){
					ammo.SetActive (true);}
			}
		}
		// SE FOR O BOSS, REDUZIR HP DE UM EM UM ATE QUE SEU HP ZERE E ENTAO A ANIMACAO FINAL SERA EXIBIDA
		if (boss)
		{
			if (mateInimigo) {
				BossHealth = BossHealth - 1;
				mateInimigo = false;
			}
			if (BossHealth == 0)
			{
//				PlayerPrefs.SetInt ("ChaveSalvarPontos", savedScore.pontuacao);
//				PlayerPrefs.SetInt ("ChaveInimigosMortos", savedScore.inimigosMortos);
				Application.LoadLevel(animFinal);
			}
		}
	}
}
