﻿using UnityEngine;
using System.Collections;

public class showScore : MonoBehaviour {

	// DECLARA E INICIALIZA VARIAVEIS

	public Weapon score;
	public bool telaPont;
	public bool telaMortes;
	void Awake ()
	{
		score = GameObject.FindObjectOfType <Weapon> ();
	}
	// Update is called once per frame

	// EXIBIR PONTUACAO NA TELA DE GAME OVER OU NA TELA INGAME
	void Update () {

		if (telaPont) {
			guiText.text = "" + score.pontuacao;
				}
		else if (telaMortes){
			guiText.text = "" + score.inimigosMortos;
		}else
		guiText.text = "Pontuação: " + score.pontuacao;
		
	}
}
