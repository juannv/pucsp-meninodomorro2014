﻿using UnityEngine;
using System.Collections;

public class AIWayPointsCS : MonoBehaviour {

	// DECLARACAO DE VARIAVEIS
	public Transform wayPointCorrente  = null;
	public float velocidade  = 1.0f;				// velocidade de movimento
	public GameObject jogador ;
	public float distanciaCalculada ;
	public float anguloCalculado ;
	public float distanciaMinima  = 2.0f;
	public float anguloMinimo  = 15.0f;
	public bool moveParaJogador  = false;
	public bool enxergaJogador = false;
	public LayerMask layerMaskEnemy ;
	public Animator animator ;
	public bool ignorarJogador  = false;
	public bool e1hands ;
	public bool e1pistol ;
	public bool e1smg ;
	public bool e1shotgun ;
	public bool e2hands ;
	public bool e2pistol ;
	public bool e2smg ;
	public bool e2shotgun ;
	public float fireRate = 0.5f;
	private float nextFire = 0.0f;
	
	
	public void Start() {
		
		jogador = GameObject.FindGameObjectWithTag("Player");
		animator = this.gameObject.GetComponentInChildren<Animator>();
	}
	
	// tela de pontuacao vai grapontos, inimigos mortos e a fase anterior numa string
	public void Update () {
		
		//Debug.Log("Nome inimigo: " + gameObject.name + " enxerga: " + enxergaJogador);
		
		float distanciaCalculada = Vector3.Distance(jogador.transform.position,transform.position);
		float anguloCalculado = Vector3.Angle(jogador.transform.position,transform.position);

		// MOVER-SE EM DIRECAO DESDE QUE A DISTANCIA E ANGULO ESTEJAM DENTRO DOS LIMITES, NPC DEVE OLHAR EM DIRECAO AO JOGADOR

		if(ignorarJogador == false) {
			if (distanciaCalculada <= distanciaMinima)
			{
				if (enxergaJogador)
				{
					if (anguloCalculado <= anguloMinimo)
					{
						moveParaJogador = true;
						transform.position = Vector3.MoveTowards(transform.position,jogador.transform.position,velocidade * Time.deltaTime);
						transform.LookAt(jogador.transform.position);
					} else {
						moveParaJogador = false;
					}
					
				} else {
					moveParaJogador = false;
				}
			} else {
				moveParaJogador = false;
			}
			
			
			// SE INIMIGO1 ESTIVER DESARMADO, A PARTIR DESTA DISTANCIA TOCAR ANIMACAO E AUDIO DE SOCO 
			/**/		if (e1hands)
			{
				if (moveParaJogador && distanciaCalculada < 0.4f)
				{
					animator.Play("Inimigo1 - Bare Shoot");
					audio.Play();
				}
			}
			// SE INIMIGO2 ESTIVER DESARMADO, A PARTIR DESTA DISTANCIA TOCAR ANIMACAO E AUDIO DE SOCO 
			/**/		if (e2hands)
			{
				if (moveParaJogador && distanciaCalculada < 0.4f)
				{
					animator.Play("Inimigo2 - Bare Shoot");
					audio.Play();
				}
			}

			// SE INIMIGO1 ESTIVER ARMADO COM UMA PISTOLA, A PARTIR DESTA DISTANCIA E COM O TEMPO DEFINIDO, TOCAR ANIMACAO E AUDIO DE TIRO  E DISPARAR EM DIRECAO AO JOGADOR

			/**/		else if (e1pistol)
			{
				if (moveParaJogador && distanciaCalculada < 2.0f && Time.time > nextFire)
				{
					nextFire = Time.time + fireRate;
					animator.Play("Inimigo1 - Pistol Shoot");
					audio.Play();		
				RaycastHit2D hit1  = Physics2D.Linecast(transform.position, jogador.transform.position, layerMaskEnemy);
					if(hit1.collider != null) {
					if(hit1.collider.gameObject.tag.Equals("Player")) {
						jogador.GetComponent<morte>().jogadorMorre();
					}
					} else {
						enxergaJogador = false;
					}

					//Debug.DrawLine (transform.position, hit.point, Color.red); 
				}
			}

			// SE INIMIGO2 ESTIVER ARMADO COM UMA PISTOLA, A PARTIR DESTA DISTANCIA E COM O TEMPO DEFINIDO, TOCAR ANIMACAO E AUDIO DE TIRO  E DISPARAR EM DIRECAO AO JOGADOR

			/**/		else if (e2pistol)
			{
				if (moveParaJogador && distanciaCalculada < 2.0f && Time.time > nextFire)
				{
					nextFire = Time.time + fireRate;
					animator.Play("Inimigo2 - Pistol Shoot");
					audio.Play();
					
					RaycastHit2D hit4  = Physics2D.Linecast(transform.position, jogador.transform.position, layerMaskEnemy);
					if(hit4.collider != null) {
					if(hit4.collider.gameObject.tag.Equals("Player")) {
						jogador.GetComponent<morte>().jogadorMorre();
					}
					} else {
						enxergaJogador = false;
					}
					//Debug.DrawLine (transform.position, hit.point, Color.red);

				}
			}

			// SE INIMIGO1 ESTIVER ARMADO COM UMA SMG, A PARTIR DESTA DISTANCIA E COM O TEMPO DEFINIDO, TOCAR ANIMACAO E AUDIO DE TIRO  E DISPARAR EM DIRECAO AO JOGADOR

			/**/		else if (e1smg)
			{
				if (moveParaJogador && distanciaCalculada < 2.0f && Time.time > nextFire)
				{
					nextFire = Time.time + fireRate;	
					animator.Play("Inimigo1 - SMG Shoot");
					audio.Play();
					
					RaycastHit2D hit2 = Physics2D.Linecast(transform.position, jogador.transform.position, layerMaskEnemy);
					if(hit2.collider != null) {
					if(hit2.collider.gameObject.tag.Equals("Player")) {
						jogador.GetComponent<morte>().jogadorMorre();
					}
					} else {
						enxergaJogador = false;
					}

				}
			}

			// SE INIMIGO2 ESTIVER ARMADO COM UMA SMG, A PARTIR DESTA DISTANCIA E COM O TEMPO DEFINIDO, TOCAR ANIMACAO E AUDIO DE TIRO  E DISPARAR EM DIRECAO AO JOGADOR

			/**/		else if (e2smg)
			{
				if (moveParaJogador && distanciaCalculada < 2.0f && Time.time > nextFire)
				{
					nextFire = Time.time + fireRate;	
					animator.Play("Inimigo2 - SMG Shoot");
					audio.Play();
					
					RaycastHit2D hit5 = Physics2D.Linecast(transform.position, jogador.transform.position, layerMaskEnemy);
					if(hit5.collider != null) {
					if(hit5.collider.gameObject.tag.Equals("Player")) {
						jogador.GetComponent<morte>().jogadorMorre();
					}
					} else {
						enxergaJogador = false;
					}

				}
			}

			// SE INIMIGO1 ESTIVER ARMADO COM UMA SHOTGUN, A PARTIR DESTA DISTANCIA E COM O TEMPO DEFINIDO, TOCAR ANIMACAO E AUDIO DE TIRO  E DISPARAR EM DIRECAO AO JOGADOR

			/**/		else if (e1shotgun)
			{
				if (moveParaJogador && distanciaCalculada < 2.0f && Time.time > nextFire)
				{
					nextFire = Time.time + fireRate;
					animator.Play("Inimigo1 - Shotgun Shoot");
					audio.Play();
					
					RaycastHit2D hit6 = Physics2D.Linecast(transform.position, jogador.transform.position, layerMaskEnemy);
					if(hit6.collider != null) {
					if(hit6.collider.gameObject.tag.Equals("Player")) {
						jogador.GetComponent<morte>().jogadorMorre();
					}
					} else {
						enxergaJogador = false;
					}

				}
			}

			// SE INIMIGO2 ESTIVER ARMADO COM UMA SHOTGUN, A PARTIR DESTA DISTANCIA E COM O TEMPO DEFINIDO, TOCAR ANIMACAO E AUDIO DE TIRO  E DISPARAR EM DIRECAO AO JOGADOR

			/**/		else if (e2shotgun)
			{
				if (moveParaJogador && distanciaCalculada < 2.0f && Time.time > nextFire)
				{
					nextFire = Time.time + fireRate;
					animator.Play("Inimigo2 - Shotgun Shoot");
					audio.Play();
					
					RaycastHit2D hit3 = Physics2D.Linecast(transform.position, jogador.transform.position, layerMaskEnemy);
					if(hit3.collider != null) {
						if(hit3.collider.gameObject.tag.Equals("Player")) {
							jogador.GetComponent<morte>().jogadorMorre();
						}
					} else {
						enxergaJogador = false;
					}
				}
			}
			
			
			if(wayPointCorrente != null && moveParaJogador == false) {			// se o waypoint atual nao for vazio
				
				transform.position = Vector3.MoveTowards(transform.position,wayPointCorrente.position,velocidade * Time.deltaTime);		// mover em direcao ao proximo waypoint na velocidade definida
				transform.LookAt(wayPointCorrente);										// olhar em direcao ao waypoint enquanto se move em direcao a ele  
			}
		} else {
			if(wayPointCorrente != null) {			// se o waypoint atual nao for vazio
				transform.position = Vector3.MoveTowards(transform.position,wayPointCorrente.position,velocidade * Time.deltaTime);		// mover em direcao ao proximo waypoint na velocidade definida
				transform.LookAt(wayPointCorrente);										// olhar em direcao ao waypoint enquanto se move em direcao a ele  
			}
		}
		
	}

	// NPC ANDA EM LINHA RETA ATE SEU PROXIMO WAYPOINT, A NAO SER QUE PLAYER ENTRE EM SEU CAMPO DE VISAO, ESTE ENTAO SE TORNA SEU PROXIMO WAYPOINT
	public void FixedUpdate () {
		RaycastHit2D informaCaoColisao  = Physics2D.Linecast(transform.position,jogador.transform.position,layerMaskEnemy);
		//Debug.Log(informaCaoColisao.collider.tag);
		if(informaCaoColisao.collider != null) {
			if(informaCaoColisao.collider.tag.Equals("Player")) {
				enxergaJogador = true;
			} else {
				enxergaJogador = false;
			}
		}
	}

	// AO COLIDIR CM O JOGADOR, JOGADOR MORRE
	public void OnCollisionEnter2D(Collision2D colisorPlayer) {
		if (colisorPlayer.gameObject.tag == "Player")
		{
			jogador.GetComponent<morte>().jogadorMorre();
			moveParaJogador =  false;
			enxergaJogador = false;
		}
	}
	// IGNORAR JOGADOR
	public void IgnorarPlayer() {
		ignorarJogador = true;
	}

	// AO TOCAR EM UM TRIGGER (WAYPOINT), O PROXIMO WAYPOINT VINCULADO A ESTE SERA O PROXIMO WAYPOINT DO NPC
	public void OnTriggerEnter2D(Collider2D objeto) {
		if(objeto.tag.Equals("Waypoint")) {								// se a tag do objeto colidido for waypoint
			ProximosWaypointsCS proximosWaypoints = objeto.GetComponent<ProximosWaypointsCS>();		// define possiveis waypoints
			Transform proximoWayPoint  = proximosWaypoints.ObterProximaPosicao();							// alterar o proximo waypoint
			// Calculo de tempo
			//velocidade = Vector3.Distance(proximoWayPoint.position,gameObject.transform.position)/tempoDeslocamento;
			wayPointCorrente = proximoWayPoint;						// waypoint atual volta para a lista de proximos waypoints
		}
	}



}
